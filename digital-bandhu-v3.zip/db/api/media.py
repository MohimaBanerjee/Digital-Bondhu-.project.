"""Vercel /api/media"""
import sys,os,json
sys.path.insert(0,os.path.join(os.path.dirname(__file__),".."))
from detection import detect_media
def handler(req,res):
    res.headers["Content-Type"]="application/json"
    res.headers["Access-Control-Allow-Origin"]="*"
    res.headers["Access-Control-Allow-Methods"]="POST,OPTIONS"
    res.headers["Access-Control-Allow-Headers"]="Content-Type"
    if req.method=="OPTIONS":res.status_code=200;res.body="";return res
    if req.method!="POST":res.status_code=405;res.body=json.dumps({"success":False,"error":"Use POST"});return res
    try:b=json.loads(req.body) if req.body else {}
    except:res.status_code=400;res.body=json.dumps({"success":False,"error":"Invalid JSON"});return res
    fn=b.get("filename","file");ft=b.get("filetype","");fs=int(b.get("filesize",0))
    if not ft:res.status_code=400;res.body=json.dumps({"success":False,"error":"filetype required"});return res
    from datetime import datetime
    r=detect_media(fn,ft,fs)
    res.status_code=200
    res.body=json.dumps({"success":True,"input":str(fn)[:120],"score":r["score"],"level":r["level"],"reasons":r["reasons"],"action":r.get("action",""),"timestamp":datetime.utcnow().isoformat()+"Z"})
    return res
