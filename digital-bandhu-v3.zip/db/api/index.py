"""Vercel /health"""
import json
from datetime import datetime
def handler(req,res):
    res.status_code=200;res.headers["Content-Type"]="application/json"
    res.body=json.dumps({"status":"ok","service":"Digital Bandhu","version":"2.0","timestamp":datetime.utcnow().isoformat()+"Z"})
    return res
