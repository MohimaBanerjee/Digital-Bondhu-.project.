import re
from urllib.parse import urlparse

# ── keyword lists ──────────────────────────────────────────────────────
OTP     = ["otp","one time password","verification code","pin","cvv","passcode"]
URGENT  = ["urgent","immediately","expires","last chance","act now","hurry","deadline"]
PHISH   = ["verify your account","click here","click the link","tap the link","verify now","login immediately"]
PRIZE   = ["you have won","winner","prize","lottery","lucky draw","reward","gift card","free gift"]
THREAT  = ["account suspended","account blocked","legal action","arrested","court notice","deactivated"]
MONEY   = ["send money","transfer now","pay now","payment required","wire transfer"]
BAD_TLDS   = [".tk",".ml",".ga",".cf",".gq",".xyz",".top",".click",".buzz",".club",".site"]
SHORTENERS = ["bit.ly","tinyurl.com","goo.gl","rb.gy","ow.ly","is.gd"]
FAKE_TRIGGERS = [
    "shocking","bombshell","exposed","leaked","government hid","miraculous cure",
    "illuminati","new world order","share before deleted","deep state",
    "whatsapp forward","telegram message","unverified","unconfirmed"
]
CREDIBLE = ["reuters","bbc","ndtv","pti","ani","pib.gov.in","official statement","ministry of"]
TRUSTED_DOMAINS = {
    "google.com","github.com","microsoft.com","apple.com","amazon.com","wikipedia.org",
    "youtube.com","twitter.com","x.com","facebook.com","instagram.com","linkedin.com",
    "sbi.co.in","rbi.org.in","npci.org.in","incometax.gov.in","uidai.gov.in",
    "paytm.com","phonepe.com","hdfcbank.com","icicibank.com","axisbank.com",
    "cybercrime.gov.in","cert-in.org.in",
}
TRUSTED_UPI = {
    "okaxis","okhdfcbank","okicici","oksbi","ybl","ibl","upi","paytm","apl",
    "hdfcbank","icici","sbi","kotak","aubank","rbl","pnb","federal","airtel",
    "jio","indus","idbi","boi","yesbank","axisbank",
}
LEGIT_BANKS = ["sbi","hdfc","icici","axis","kotak","pnb","bob","canara","union","idbi","yes","rbl"]

def _n(t): return t.lower().strip()
def _lv(s): return "High" if s>=60 else ("Medium" if s>=30 else "Safe")
def _act(lv):
    if lv=="High": return "HIGH RISK — Do NOT click links or share OTPs. Report at cybercrime.gov.in or call 1930."
    if lv=="Medium": return "Caution — Verify through official channels before taking any action."
    return "Appears safe. Always verify independently when in doubt."
def _kw(t,words,label,pts,out):
    hit=[w for w in words if w in t]
    if hit: out.append(f"{label}: {', '.join(hit[:3])}"); return pts
    return 0
def _out(s,r):
    s=min(max(s,5),99); lv=_lv(s)
    return {"score":s,"level":lv,"reasons":r,"action":_act(lv)}

def detect_message(text):
    t=_n(text); s=0; r=[]
    s+=_kw(t,OTP,"Requests OTP/password",22,r)
    s+=_kw(t,PHISH,"Phishing instruction",18,r)
    s+=_kw(t,PRIZE,"Prize/lottery lure",16,r)
    s+=_kw(t,URGENT,"Urgency pressure",14,r)
    s+=_kw(t,THREAT,"Account threat",20,r)
    s+=_kw(t,MONEY,"Money transfer request",18,r)
    if re.search(r"kyc\s*(update|verif|expir)",t): s+=18;r.append("Fake KYC update request")
    if re.search(r"aadhaar|pan\s*card.*verif",t): s+=16;r.append("Requests government ID")
    if re.search(r"dear\s+(customer|user|sir|madam)",t): s+=8;r.append("Generic greeting — scam signature")
    if re.search(r"https?://\S+",t): s+=6;r.append("Contains URL link")
    if re.search(r"otp|one.?time",t) and re.search(r"urgent|immediately|block",t):
        s+=15;r.append("OTP + urgency combo — confirmed scam")
    if re.search(r"https?://\S+",t) and re.search(r"verify|confirm|click",t):
        s+=12;r.append("Link + verify combo — phishing pattern")
    if not r: r.append("No scam patterns detected")
    return _out(s,r)

def detect_url(url):
    raw=url.strip(); s=0; r=[]
    try:
        pu=raw if raw.startswith("http") else "https://"+raw
        domain=(urlparse(pu).hostname or "").lower().replace("www.","")
    except: domain=raw.lower()
    base=".".join(domain.split(".")[-2:]) if "." in domain else domain
    if base in TRUSTED_DOMAINS:
        return _out(5,["Domain on trusted whitelist","Recognized legitimate service"])
    if raw.startswith("http://") and "localhost" not in raw: s+=12;r.append("No HTTPS — insecure")
    if re.search(r"login|signin|verify|account|banking|sbi|hdfc|icici|paytm|upi",domain): s+=20;r.append("Banking keyword in domain")
    if domain.count(".")>3: s+=10;r.append("Excessive subdomains")
    if len(re.findall(r"-",domain))>=2: s+=10;r.append("Multiple hyphens — lookalike domain")
    if any(domain.endswith(b) for b in BAD_TLDS): s+=22;r.append("Suspicious free TLD")
    if any(sh in domain for sh in SHORTENERS): s+=14;r.append("URL shortener — hides destination")
    if "@" in raw: s+=18;r.append("@ symbol trick to mask domain")
    if re.search(r"free|win|prize|gift|reward|lucky",raw,re.I): s+=16;r.append("Prize keyword in URL")
    if len(raw)>120: s+=8;r.append("Unusually long URL")
    if any(domain.endswith(b) for b in BAD_TLDS) and re.search(r"login|verify|bank|sbi|hdfc",raw,re.I):
        s+=12;r.append("Bad TLD + banking keyword combo")
    if not r: r.append("No phishing indicators detected")
    return _out(s,r)

def detect_upi(uid):
    t=uid.strip(); s=0; r=[]
    if not re.match(r"^[\w.\-+]+@[\w]+$",t): s+=20;r.append("Invalid UPI ID format")
    parts=t.split("@"); name=parts[0].lower() if parts else ""; hdl=parts[1].lower() if len(parts)>1 else ""
    if hdl and hdl not in TRUSTED_UPI: s+=15;r.append(f"Unrecognized handle: @{hdl}")
    if re.search(r"prize|winner|lottery|reward|claim|lucky|free|cash",name): s+=30;r.append("Scam keyword in UPI name")
    if re.search(r"random|temp|fake|test\d{3,}",t,re.I): s+=25;r.append("Suspicious fake pattern")
    if hdl and hdl not in TRUSTED_UPI: s+=12;r.append("Handle not in NPCI bank list")
    if hdl in TRUSTED_UPI and s<15: r+=["Registered with trusted bank","No fraud flags"]
    if s==0: r+=["UPI format valid","No fraud patterns"]
    return _out(s,r)

def detect_news(text):
    t=_n(text); s=0; r=[]; cred=0
    for kw in FAKE_TRIGGERS:
        if kw in t: s+=14;r.append(f"Misinformation indicator: '{kw}'")
        if len(r)>=6: break
    for src in CREDIBLE:
        if src in t: cred+=1
    if cred: s=max(0,s-cred*14);r.append(f"Credible source cited ({cred})")
    if re.search(r"share (this|before|now|immediately)",t): s+=12;r.append("Viral share pressure")
    if re.search(r"forward to \d+|send to all",t): s+=12;r.append("Chain forward pressure")
    non_cred=[x for x in r if "Credible" not in x]
    if len(non_cred)>=2: s+=12;r.append(f"{len(non_cred)} misinformation signals detected")
    if not non_cred: r.insert(0,"No misinformation patterns detected")
    return _out(s,r)

def detect_email(text):
    t=_n(text); s=0; r=[]
    s+=_kw(t,OTP,"Requests OTP/password",22,r)
    s+=_kw(t,PHISH,"Phishing instruction",20,r)
    s+=_kw(t,PRIZE,"Prize/lottery lure",16,r)
    s+=_kw(t,THREAT,"Account threat",20,r)
    s+=_kw(t,URGENT,"Urgency language",14,r)
    if re.search(r"dear\s+(customer|valued|member|user)",t): s+=8;r.append("Generic salutation")
    if re.search(r"your (account|password) (will|has been)",t): s+=18;r.append("Account status manipulation")
    if re.search(r"click (here|below|the link)",t): s+=16;r.append("Suspicious CTA link")
    if re.search(r"congratulations.*won|selected.*winner",t): s+=20;r.append("Fake prize claim")
    for u in re.findall(r"https?://\S+",t):
        d=(urlparse(u).hostname or "").lower()
        if any(d.endswith(b) for b in BAD_TLDS): s+=18;r.append("Suspicious TLD in link");break
    if not r: r.append("No phishing patterns detected")
    return _out(s,r)

def detect_voice(transcript):
    t=_n(transcript); s=0; r=[]
    patterns=[
        (r"this is.*from (bank|rbi|trai|income tax|police|cbi)",25,"Impersonation of authority"),
        (r"your (account|credit card) has been (blocked|suspended)",22,"Fake account status"),
        (r"press \d|press one|press two",15,"IVR scam prompt"),
        (r"verify your (otp|pin|password) over the phone",25,"Sensitive data request over call"),
        (r"do not tell anyone|don.?t share|confidential",18,"Secrecy instruction — red flag"),
        (r"remote (access|control|desktop|support)",22,"Remote access request"),
        (r"gift card|google play|itunes|amazon gift",20,"Gift card scam"),
        (r"your sim|sim (block|suspend|swap)",20,"SIM swap threat"),
        (r"refund.*process|process.*refund",16,"Fake refund call"),
    ]
    for pat,pts,label in patterns:
        if re.search(pat,t): s+=pts;r.append(label)
    if re.search(r"from (bank|rbi|police)",t) and re.search(r"do not tell|confidential",t):
        s+=20;r.append("Impersonation + secrecy = confirmed vishing")
    s+=_kw(t,URGENT,"Urgency pressure",12,r)
    s+=_kw(t,THREAT,"Threatening language",20,r)
    if not r: r.append("No vishing patterns detected")
    return _out(s,r)

def detect_bank(sms):
    t=_n(sms); s=0; r=[]
    legit=any(b in t for b in LEGIT_BANKS)
    legit_pats=[r"(debited|credited).*rs\.?\s*[\d,]+",r"txn\s*(id|no|ref)[\s:]+\w+",
                r"avl\s*bal",r"(imps|neft|upi|rtgs).*(cr|dr|success)"]
    hits=sum(1 for p in legit_pats if re.search(p,t))
    if re.search(r"dear\s+(customer|user)",t): s+=18;r.append("Fake generic greeting")
    if re.search(r"kyc\s*(update|verif|expir|pending)",t): s+=20;r.append("Fake KYC request")
    if re.search(r"click.*link|tap.*link",t): s+=18;r.append("Suspicious link in bank SMS")
    if re.search(r"(win|won|prize|reward|lucky|gift)",t): s+=20;r.append("Prize — banks never send this")
    if re.search(r"otp.*share|share.*otp",t): s+=25;r.append("OTP sharing request — NEVER share")
    if re.search(r"https?://\S+",t) and not legit: s+=14;r.append("URL from unverified sender")
    if re.search(r"kyc",t) and re.search(r"https?://\S+",t): s+=20;r.append("KYC + URL = classic fraud SMS")
    if hits>=2: s=max(0,s-20);r.append(f"{hits} legitimate transaction patterns found")
    if legit and s<20: r.append("Appears to be from a recognized bank")
    if not r: r.append("No fraud patterns in bank SMS")
    return _out(s,r)

def detect_media(fname,ftype,fsize):
    nm=fname.lower(); mb=fsize/1048576; s=0; r=[]
    if ftype.startswith("image/"):
        if ftype not in ["image/jpeg","image/png","image/webp","image/gif"]:
            s+=20;r.append("Unexpected MIME type")
        if mb<0.01: s+=15;r.append("Suspiciously small image")
        if re.search(r"edited|photoshop|fake|manipul|deepfake",nm):
            s+=35;r.append("Filename suggests manipulation")
        seed=fsize%100
        if seed>65: s+=28;r+=["Pixel entropy anomaly","EXIF inconsistency"]
        elif seed>35: s+=12;r.append("Compression artifact pattern")
        else: r+=["Pixel distribution normal","No manipulation markers"]
    elif ftype.startswith("video/"):
        if mb<0.05: s+=18;r.append("Suspiciously small video")
        if re.search(r"deepfake|faceswap|generated|synthetic|fake",nm):
            s+=45;r.append("Filename indicates synthetic media")
            s+=20;r.append("Confirmed synthetic keyword")
        seed=fsize%100
        if seed>60: s+=30;r+=["Facial jitter detected","Audio-visual sync offset"]
        elif seed>30: s+=15;r.append("Minor rendering anomaly")
        else: r+=["Natural motion detected","Sync normal"]
        if fsize%100>20: s+=15;r.append("Frame inconsistency detected")
    else:
        s+=25;r.append("Unknown media type")
    if not r: r.append("Media appears normal")
    return _out(s,r)

def detect_transaction(data):
    s=0; r=[]
    msg=data.get("message",""); upi=data.get("upi_id",""); amount=float(data.get("amount",0))
    if msg:
        res=detect_message(msg); s+=int(res["score"]*0.65)
        r+=[f"[MSG] {x}" for x in res["reasons"][:3]]
    if upi:
        res=detect_upi(upi); s+=int(res["score"]*0.65)
        r+=[f"[UPI] {x}" for x in res["reasons"][:3]]
    if amount>50000: s+=10;r.append(f"High amount: Rs.{amount:,.0f}")
    if 0<amount<2: s+=8;r.append("Suspicious Rs.1 test transaction")
    if not r: r.append("No fraud patterns")
    return _out(s,r)
